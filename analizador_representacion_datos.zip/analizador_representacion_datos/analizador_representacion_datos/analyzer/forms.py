from django import forms

BASE_CHOICES = [
    ("2", "Binario (base 2)"),
    ("8", "Octal (base 8)"),
    ("10", "Decimal (base 10)"),
    ("16", "Hexadecimal (base 16)"),
]

class NumberForm(forms.Form):
    number = forms.CharField(
        label="Número",
        max_length=32,
        widget=forms.TextInput(attrs={"placeholder": "Ej. 101101", "autocomplete": "off"}),
        error_messages={"required": "Escribe un número; el campo no puede quedar vacío."},
    )
    base = forms.ChoiceField(label="Base de origen", choices=BASE_CHOICES)

    def clean_number(self):
        raw = self.cleaned_data["number"].strip()
        if not raw:
            raise forms.ValidationError("Escribe un número; el campo no puede quedar vacío.")
        base_key = self.add_prefix("base")
        base_raw = self.data.get(base_key, "10")
        base = int(base_raw) if base_raw in {"2", "8", "10", "16"} else 10
        if raw.startswith("-"):
            raise forms.ValidationError("No se permiten valores negativos.")
        if raw.startswith("+"):
            raw = raw[1:]
        if not raw:
            raise forms.ValidationError("Escribe un número válido.")
        allowed = {
            2: set("01"),
            8: set("01234567"),
            10: set("0123456789"),
            16: set("0123456789abcdefABCDEF"),
        }[base]
        if any(char not in allowed for char in raw):
            raise forms.ValidationError(
                f"Hay dígitos inválidos para la base {base}. Revisa el número ingresado."
            )
        try:
            value = int(raw, base)
        except ValueError:
            raise forms.ValidationError("No se pudo interpretar el número.")
        if value > 65535:
            raise forms.ValidationError("El valor está fuera del rango permitido: 0 a 65 535.")
        self.number_value = value
        return raw

    def result(self):
        value = self.number_value
        bits = max(1, value.bit_length())
        padded_bits = ((bits + 7) // 8) * 8
        return {
            "decimal": value,
            "binary": format(value, f"0{padded_bits}b"),
            "octal": format(value, "o"),
            "hexadecimal": format(value, "X"),
            "significant_bits": bits,
            "bytes": (bits + 7) // 8,
        }

class TextForm(forms.Form):
    text = forms.CharField(
        label="Texto (máximo 20 caracteres)",
        max_length=20,
        required=True,
        widget=forms.TextInput(attrs={"placeholder": "Ej. España, año, niño", "autocomplete": "off"}),
        error_messages={
            "required": "Escribe un texto; el campo no puede quedar vacío.",
            "max_length": "El texto no puede superar los 20 caracteres.",
        },
    )

    def clean_text(self):
        value = self.cleaned_data["text"]
        if not value:
            raise forms.ValidationError("Escribe un texto; el campo no puede quedar vacío.")
        if len(value) > 20:
            raise forms.ValidationError("El texto no puede superar los 20 caracteres.")
        return value

    def result(self):
        rows = []
        for char in self.cleaned_data["text"]:
            codepoint = ord(char)
            encoded = char.encode("utf-8")
            rows.append({
                "character": char if char != " " else "␠ (espacio)",
                "decimal": codepoint,
                "unicode": f"U+{codepoint:04X}",
                "hexadecimal": f"{codepoint:X}",
                "utf8": " ".join(f"{byte:02X}" for byte in encoded),
            })
        return rows
