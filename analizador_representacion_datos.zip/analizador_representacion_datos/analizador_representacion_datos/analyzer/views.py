from django.shortcuts import render
from .forms import NumberForm, TextForm

def index(request):
    number_form = NumberForm(request.POST or None, prefix="num")
    text_form = TextForm(request.POST or None, prefix="txt")
    number_result = None
    text_result = None

    if request.method == "POST":
        form_type = request.POST.get("form_type")
        if form_type == "number" and number_form.is_valid():
            number_result = number_form.result()
        elif form_type == "text" and text_form.is_valid():
            text_result = text_form.result()

    return render(request, "analyzer/index.html", {
        "number_form": number_form,
        "text_form": text_form,
        "number_result": number_result,
        "text_result": text_result,
    })
