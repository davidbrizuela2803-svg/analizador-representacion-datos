from django.test import TestCase
from .forms import NumberForm, TextForm

class NumberFormTests(TestCase):
    def make_form(self, number, base):
        return NumberForm(data={"number": number, "base": str(base)})

    def test_binary_conversion(self):
        form = self.make_form("101101", 2)
        self.assertTrue(form.is_valid())
        result = form.result()
        self.assertEqual(result["decimal"], 45)
        self.assertEqual(result["binary"], "00101101")
        self.assertEqual(result["bytes"], 1)

    def test_octal_conversion(self):
        form = self.make_form("17", 8)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.result()["decimal"], 15)

    def test_decimal_conversion(self):
        form = self.make_form("255", 10)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.result()["hexadecimal"], "FF")

    def test_hex_conversion(self):
        form = self.make_form("FFFF", 16)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.result()["decimal"], 65535)
        self.assertEqual(form.result()["binary"], "1111111111111111")

    def test_invalid_digit_for_base(self):
        form = self.make_form("102", 2)
        self.assertFalse(form.is_valid())
        self.assertIn("dígitos inválidos", str(form.errors).lower())

    def test_out_of_range(self):
        form = self.make_form("65536", 10)
        self.assertFalse(form.is_valid())
        self.assertIn("fuera del rango", str(form.errors).lower())

    def test_negative_value(self):
        form = self.make_form("-1", 10)
        self.assertFalse(form.is_valid())
        self.assertIn("negativos", str(form.errors).lower())

    def test_empty_number(self):
        form = self.make_form("", 10)
        self.assertFalse(form.is_valid())

class TextFormTests(TestCase):
    def test_enye_utf8(self):
        form = TextForm(data={"text": "ñ"})
        self.assertTrue(form.is_valid())
        row = form.result()[0]
        self.assertEqual(row["decimal"], 241)
        self.assertEqual(row["unicode"], "U+00F1")
        self.assertEqual(row["utf8"], "C3 B1")

    def test_text_maximum_length(self):
        form = TextForm(data={"text": "abcdefghijklmnopqrstu"})
        self.assertFalse(form.is_valid())
