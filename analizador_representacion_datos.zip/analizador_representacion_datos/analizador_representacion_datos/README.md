# Analizador de representación de datos

Aplicación web con Python 3.12 y Django para convertir números entre bases 2, 8, 10 y 16, y examinar la codificación Unicode/UTF-8 de textos de hasta 20 caracteres.

## Requisitos

- Docker Desktop (Windows/macOS) o Docker Engine y el complemento Docker Compose.
- Alternativamente, Python 3.12 para ejecución local.

## Ejecutar con Docker

Desde la carpeta raíz del proyecto:

```bash
docker compose build
docker compose up -d
docker compose ps
```

Abrir http://localhost:8000 en el navegador.

El servicio se configura en `compose.yaml` con un máximo de 256 MB de RAM y 1 CPU. Para detenerlo:

```bash
docker compose down
```

## Evidencia de consumo (`docker stats`)

Con el contenedor activo, ejecutar:

```bash
docker stats analizador-datos
```

Tomar una captura de pantalla donde se vean el nombre del contenedor, CPU %, uso/límite de memoria y la aplicación activa. Para una salida de una sola lectura:

```bash
docker stats --no-stream analizador-datos
```

La salida real depende de la máquina y del uso en ese momento; no se debe copiar una cifra inventada como evidencia.

## Ejecutar localmente sin Docker

```bash
py -3.12 -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# Linux/macOS:
# source .venv/bin/activate
pip install -r requirements.txt
python manage.py runserver
```

Abrir http://127.0.0.1:8000.

## Pruebas automatizadas

Con Docker activo:

```bash
docker compose exec web python manage.py test analyzer
```

O en el entorno local:

```bash
python manage.py test analyzer
```

Las pruebas cubren conversiones en diferentes bases, relleno binario por bytes, dígitos inválidos, valor negativo, rango máximo, entrada vacía, límite de texto y UTF-8 para `ñ`.

## Funcionamiento

### Sistemas numéricos

La aplicación interpreta el valor en la base seleccionada y lo convierte a entero. Se permite el rango de 0 a 65 535. El binario se completa con ceros a la izquierda hasta un múltiplo de 8 bits. Los bits significativos son `bit_length()` (para cero se muestra 1 bit como representación mínima); los bytes necesarios se calculan redondeando los bits significativos hacia arriba en grupos de ocho.

### Unicode y UTF-8

Por cada carácter se muestra su valor decimal (`ord`), punto de código Unicode (por ejemplo, `U+00F1` para `ñ`), hexadecimal y los bytes que devuelve `encode("utf-8")`. En UTF-8, `ñ` se representa con los bytes `C3 B1`.

## Arquitectura de Von Neumann

- **Entrada:** el teclado y los formularios permiten ingresar números y texto.
- **Memoria:** la RAM mantiene el proceso de Python/Django, las variables, los formularios y los resultados durante la ejecución.
- **Unidad de control y ejecución:** la CPU ejecuta las instrucciones de Python y del sistema operativo que realizan las validaciones y conversiones.
- **Salida:** el navegador presenta las conversiones, tablas y mensajes de validación en pantalla.
- **Almacenamiento:** el código del proyecto y las imágenes del contenedor están guardados en archivos. Esta versión no necesita una base de datos para funcionar.

La arquitectura de Von Neumann describe, de forma general, una computadora donde las instrucciones y los datos se almacenan en memoria y la CPU procesa instrucciones. Esta aplicación utiliza esos recursos a través del sistema operativo y del intérprete de Python.

## ¿Por qué Docker comparte el kernel del host?

Los contenedores aíslan procesos y recursos usando mecanismos del sistema operativo, como namespaces y cgroups, pero no incluyen un kernel completo propio. Por eso el contenedor utiliza el kernel del sistema anfitrión. La imagen `python:3.12-slim` contiene Python y las dependencias necesarias, mientras que Docker aplica los límites configurados de memoria y CPU. En Docker Desktop sobre Windows o macOS, normalmente el kernel Linux se ejecuta dentro de una máquina virtual administrada por Docker Desktop.

## Guion para el video (máximo 2 minutos)

1. **0:00–0:20:** mostrar la página y convertir, por ejemplo, `101101` en base 2.
2. **0:20–0:40:** ingresar `102` en base 2 y mostrar el mensaje de dígitos inválidos.
3. **0:40–1:00:** escribir `España ñ` en el analizador de texto y mostrar los valores Unicode y UTF-8.
4. **1:00–1:25:** ejecutar `docker compose exec web python manage.py test analyzer` y mostrar las pruebas aprobadas.
5. **1:25–1:50:** mostrar `docker compose ps` y `docker stats --no-stream analizador-datos`.
6. **1:50–2:00:** cerrar mostrando el nombre del proyecto y el repositorio.

## Publicar en GitHub

1. Crear un repositorio nuevo en GitHub llamado `analizador-representacion-datos`.
2. Descomprimir el proyecto y abrir una terminal en la carpeta que contiene `manage.py`.
3. Ejecutar:

```bash
git init
git add .
git commit -m "Crear analizador de representación de datos"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/analizador-representacion-datos.git
git push -u origin main
```

Reemplaza `TU-USUARIO` por tu usuario real de GitHub. Si Git no está instalado o pide iniciar sesión, instala Git y completa la autenticación de GitHub. No publiques contraseñas ni claves privadas.

## Lista de entrega

- [ ] Código fuente y README en GitHub o Google Drive.
- [ ] Captura de una conversión válida.
- [ ] Captura de un error de validación.
- [ ] Captura del análisis de `ñ`.
- [ ] Captura de las pruebas automatizadas aprobadas.
- [ ] Captura real de `docker stats`.
- [ ] Video de demostración de máximo 2 minutos.

**Nota:** `DEBUG=True` y la clave de desarrollo son para esta práctica local. No uses esta configuración tal cual para publicar el servicio en Internet como una aplicación de producción.
